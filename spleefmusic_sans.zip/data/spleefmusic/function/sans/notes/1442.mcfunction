playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 1.423228 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 0.711614 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 0.711614 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.10 0.886279 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 1.415031 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.16 0.707515 1
scoreboard players set @s nbs_sans_t 1442