playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.27 0.707515 1
playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.30 0.741405 1
scoreboard players set @s nbs_sans_t 1375