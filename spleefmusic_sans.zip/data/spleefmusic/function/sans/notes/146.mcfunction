playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 1 0.794159 1
playsound minecraft:block.note_block.pling player @s ^0 ^ ^ 0.60 1.060075 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.794159 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.794159 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.588318 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 0.533108 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.066216 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 1.066216 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 1.588318 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 0.794159 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 0.944420 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 1.189894 1
playsound minecraft:block.note_block.pling player @s ^-0.60 ^ ^ 0.30 1.123111 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.782827 1
scoreboard players set @s nbs_sans_t 146