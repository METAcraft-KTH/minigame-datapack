playsound minecraft:block.note_block.snare player @s ^1 ^ ^ 0.70 1.000578 1
scoreboard players set @s nbs_sans_t 129