playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 1 0.630325 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.794159 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.260649 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.630325 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 0.886279 1
playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.50 0.886279 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.630325 1
playsound minecraft:block.note_block.basedrum player @s ^1 ^ ^ 1 0.707515 1
playsound minecraft:block.note_block.basedrum player @s ^-1 ^ ^ 1 0.530038 1
scoreboard players set @s nbs_sans_t 1046