playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.25 1.415031 1
playsound minecraft:block.note_block.pling player @s ^0.90 ^ ^ 0.20 0.681444 1
scoreboard players set @s nbs_sans_t 1391