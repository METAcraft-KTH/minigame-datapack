playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 0.564808 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.129617 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 1.129617 1
scoreboard players set @s nbs_sans_t 110