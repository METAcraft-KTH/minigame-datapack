playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 1 0.630325 1
playsound minecraft:block.note_block.pling player @s ^0 ^ ^ 0.60 0.794159 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.630325 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.630325 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.260649 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.789585 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.597519 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.633976 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.630325 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.20 0.630325 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.782827 1
scoreboard players set @s nbs_sans_t 1048