playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.71 0.794159 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.10 0.643197 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.189894 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.335611 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.707515 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.13 0.794159 1
playsound minecraft:block.note_block.snare player @s ^-0.50 ^ ^ 0.10 0.944420 1
playsound minecraft:block.note_block.hat player @s ^-1 ^ ^ 0.70 0.667806 1
scoreboard players set @s nbs_sans_t 1402