playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.27 0.891413 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.20 0.789585 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.415031 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.707515 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.891413 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.060075 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
scoreboard players set @s nbs_sans_t 1204