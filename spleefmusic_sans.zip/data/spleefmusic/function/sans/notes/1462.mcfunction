playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.64 0.707515 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 1.899781 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 0.949891 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 0.949891 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.20 0.789585 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.415031 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.707515 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.891413 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.060075 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.14 0.707515 1
scoreboard players set @s nbs_sans_t 1462