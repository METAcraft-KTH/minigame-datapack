playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.899781 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.949891 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.949891 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.415031 1
scoreboard players set @s nbs_sans_t 118