playsound minecraft:block.note_block.pling player @s ^0.90 ^ ^ 0.20 0.789585 1
scoreboard players set @s nbs_sans_t 1463