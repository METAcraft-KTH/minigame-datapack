playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.667806 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 0.763571 1
playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.50 0.763571 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.20 0.667806 1
scoreboard players set @s nbs_sans_t 1126