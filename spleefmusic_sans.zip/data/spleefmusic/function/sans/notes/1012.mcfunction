playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.891413 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 1.059463 1
playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.50 1.059463 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.20 0.667806 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
playsound minecraft:block.note_block.snare player @s ^-0.30 ^ ^ 0.70 0.707515 1
playsound minecraft:block.note_block.snare player @s ^-0.90 ^ ^ 0.50 0.561555 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.060075 1
scoreboard players set @s nbs_sans_t 1012