playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.27 0.794159 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.30 0.789585 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.794159 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.189894 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.588318 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.16 0.794159 1
playsound minecraft:block.note_block.snare player @s ^-0.50 ^ ^ 0.10 0.944420 1
scoreboard players set @s nbs_sans_t 1360