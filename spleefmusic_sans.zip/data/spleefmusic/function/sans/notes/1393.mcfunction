playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.10 0.674395 1
scoreboard players set @s nbs_sans_t 1393