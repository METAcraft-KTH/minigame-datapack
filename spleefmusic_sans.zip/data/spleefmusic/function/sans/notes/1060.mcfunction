playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 1 0.594947 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.891413 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.189894 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.594947 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 0.886279 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.50 0.886279 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 1.060075 1
playsound minecraft:block.note_block.harp player @s ^0.60 ^ ^ 1 1.782827 1
playsound minecraft:block.note_block.harp player @s ^-0.60 ^ ^ 1 1.499173 1
playsound minecraft:block.note_block.pling player @s ^-0.60 ^ ^ 0.30 0.891413 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
playsound minecraft:block.note_block.snare player @s ^-0.30 ^ ^ 0.70 0.707515 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.060075 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.415031 1
scoreboard players set @s nbs_sans_t 1060