playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.81 0.630325 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.16 0.671674 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.31 1.343348 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.78 1.343348 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 0.798760 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.10 0.626694 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 0.630325 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
scoreboard players set @s nbs_sans_t 1408