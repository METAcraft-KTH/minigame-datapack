playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 0.533108 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 1.066216 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 1.066216 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.20 0.938980 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.794159 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.630325 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.260649 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.16 0.630325 1
playsound minecraft:block.note_block.snare player @s ^0.50 ^ ^ 0.40 0.944420 1
scoreboard players set @s nbs_sans_t 1438