playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.81 0.794159 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.20 0.699793 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.189894 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.415031 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.707515 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.16 0.794159 1
playsound minecraft:block.note_block.hat player @s ^-1 ^ ^ 0.70 0.667806 1
scoreboard players set @s nbs_sans_t 1386