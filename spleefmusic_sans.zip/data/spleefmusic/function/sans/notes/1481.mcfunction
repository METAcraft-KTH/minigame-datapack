playsound minecraft:block.note_block.pling player @s ^0.90 ^ ^ 0.20 0.938980 1
playsound minecraft:block.note_block.hat player @s ^1 ^ ^ 0.70 0.667806 1
scoreboard players set @s nbs_sans_t 1481