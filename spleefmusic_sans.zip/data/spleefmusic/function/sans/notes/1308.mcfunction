playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.81 0.630325 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.20 0.938980 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.794159 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.630325 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.260649 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.14 0.630325 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
playsound minecraft:block.note_block.hat player @s ^-0.90 ^ ^ 0.50 0.667806 1
scoreboard players set @s nbs_sans_t 1308