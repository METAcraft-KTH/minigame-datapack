playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.25 1.189894 1
playsound minecraft:block.note_block.pling player @s ^0.90 ^ ^ 0.20 0.688964 1
playsound minecraft:block.note_block.hat player @s ^1 ^ ^ 0.30 0.667806 1
scoreboard players set @s nbs_sans_t 1389