playsound minecraft:block.note_block.snare player @s ^1 ^ ^ 0.50 0.561555 1
scoreboard players set @s nbs_sans_t 1139