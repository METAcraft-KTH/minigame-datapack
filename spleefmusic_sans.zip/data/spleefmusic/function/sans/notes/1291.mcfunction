playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.30 0.626694 1
playsound minecraft:block.note_block.hat player @s ^1 ^ ^ 0.50 0.667806 1
scoreboard players set @s nbs_sans_t 1291