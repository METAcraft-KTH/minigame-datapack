playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.71 0.707515 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 1.597519 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 0.798760 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.30 0.789585 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.415031 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.707515 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 0.891413 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.30 1.060075 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.13 0.707515 1
playsound minecraft:block.note_block.snare player @s ^-0.50 ^ ^ 0.10 0.944420 1
playsound minecraft:block.note_block.hat player @s ^-1 ^ ^ 0.70 0.667806 1
scoreboard players set @s nbs_sans_t 1466