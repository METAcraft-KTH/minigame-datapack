playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.81 0.630325 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 0.598394 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 1.196787 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 1.196787 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.30 0.626694 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.794159 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.630325 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 0.944420 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.30 1.260649 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
playsound minecraft:block.note_block.hat player @s ^0 ^ ^ 1 0.667806 1
playsound minecraft:block.note_block.hat player @s ^0 ^ ^ 0.40 1.415031 1
scoreboard players set @s nbs_sans_t 1416