playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.597519 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.798760 1
scoreboard players set @s nbs_sans_t 0