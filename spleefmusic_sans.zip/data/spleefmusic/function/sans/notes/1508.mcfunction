playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.81 0.667806 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.19 0.798760 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.38 1.597519 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.96 1.597519 1
playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.30 0.938980 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 0.944420 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 1.189894 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 1.782827 1
playsound minecraft:block.note_block.harp player @s ^-1 ^ ^ 0.50 0.794159 1
playsound minecraft:block.note_block.snare player @s ^-0.50 ^ ^ 0.10 0.944420 1
scoreboard players set @s nbs_sans_t 1508