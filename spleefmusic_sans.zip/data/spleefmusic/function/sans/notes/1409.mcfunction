playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.10 0.626694 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 0.794159 1
scoreboard players set @s nbs_sans_t 1409