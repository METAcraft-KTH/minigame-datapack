playsound minecraft:block.note_block.pling player @s ^0 ^ ^ 0.60 0.794159 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.594947 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.794159 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.588318 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.789585 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.597519 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.798760 1
playsound minecraft:block.note_block.pling player @s ^0.50 ^ ^ 0.30 0.841382 1
playsound minecraft:block.note_block.pling player @s ^-0.60 ^ ^ 0.30 0.891413 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.20 0.794159 1
scoreboard players set @s nbs_sans_t 1118