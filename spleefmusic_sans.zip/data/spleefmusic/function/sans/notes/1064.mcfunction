playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 1 0.594947 1
playsound minecraft:block.note_block.pling player @s ^0 ^ ^ 0.60 0.944420 1
playsound minecraft:block.note_block.bit player @s ^-0.50 ^ ^ 0.40 0.594947 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.594947 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 1.189894 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.938980 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.899781 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.949891 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.949891 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.598394 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.530038 1
playsound minecraft:block.note_block.basedrum player @s ^1 ^ ^ 1 0.707515 1
playsound minecraft:block.note_block.basedrum player @s ^-1 ^ ^ 1 0.530038 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.782827 1
scoreboard players set @s nbs_sans_t 1064