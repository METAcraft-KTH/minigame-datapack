playsound minecraft:block.note_block.pling player @s ^1 ^ ^ 0.30 0.789585 1
playsound minecraft:block.note_block.hat player @s ^1 ^ ^ 0.30 0.667806 1
scoreboard players set @s nbs_sans_t 1357