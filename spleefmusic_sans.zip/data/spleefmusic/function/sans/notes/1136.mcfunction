playsound minecraft:block.note_block.pling player @s ^0 ^ ^ 0.60 0.794159 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.789585 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 0.20 1.597519 1
playsound minecraft:block.note_block.guitar player @s ^0 ^ ^ 0.40 0.798760 1
playsound minecraft:block.note_block.harp player @s ^0 ^ ^ 1 0.798760 1
playsound minecraft:block.note_block.bass player @s ^0 ^ ^ 0.20 0.667806 1
playsound minecraft:block.note_block.basedrum player @s ^1 ^ ^ 1 0.707515 1
playsound minecraft:block.note_block.basedrum player @s ^-1 ^ ^ 1 0.530038 1
playsound minecraft:block.note_block.snare player @s ^0.40 ^ ^ 0.70 0.944420 1
playsound minecraft:block.note_block.snare player @s ^-0.30 ^ ^ 0.70 0.707515 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 1 0.561555 1
playsound minecraft:block.note_block.snare player @s ^0 ^ ^ 0.40 1.415031 1
scoreboard players set @s nbs_sans_t 1136