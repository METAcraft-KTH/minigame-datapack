playsound minecraft:block.note_block.pling player @s ^-1 ^ ^ 0.10 0.886279 1
playsound minecraft:block.note_block.harp player @s ^1 ^ ^ 0.50 1.415031 1
scoreboard players set @s nbs_sans_t 1186